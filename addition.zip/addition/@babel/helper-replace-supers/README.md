# @babel/helper-replace-supers

> Helper function to replace supers

See our website [@babel/helper-replace-supers](https://babeljs.io/docs/en/babel-helper-replace-supers) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-replace-supers
```

or using yarn:

```sh
yarn add @babel/helper-replace-supers
```
