# @babel/plugin-transform-shorthand-properties

> Compile ES2015 shorthand properties to ES5

See our website [@babel/plugin-transform-shorthand-properties](https://babeljs.io/docs/en/babel-plugin-transform-shorthand-properties) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-shorthand-properties
```

or using yarn:

```sh
yarn add @babel/plugin-transform-shorthand-properties --dev
```
